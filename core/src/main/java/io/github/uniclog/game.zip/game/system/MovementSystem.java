package io.github.uniclog.game.system;

import io.github.uniclog.game.engine.System;

public class MovementSystem implements System {
    public void update(float delta) {
        // List<Entity> entities = world.getEntitiesWithComponents(PositionComponent.class, VelocityComponent.class);
        // for (Entity entity : entities) {
        //     PositionComponent position = entity.getComponent(PositionComponent.class);
        //     VelocityComponent velocity = entity.getComponent(VelocityComponent.class);
        //     // Обновляем позицию на основе скорости и времени
        //     position.x += velocity.vx * delta;
        //     position.y += velocity.vy * delta;
        // }
    }
}
