package io.github.uniclog.learn.ecs.component;

import java.util.HashMap;
import java.util.Map;

public class ComponentManagerImpl implements ComponentManager {
    private Map<Integer, Map<Class<? extends Component>, Component>> components;

    public ComponentManagerImpl() {
        components = new HashMap<>();
    }

    @Override
    public void addComponent(int entityId, Component component) {
        components.computeIfAbsent(entityId, k -> new HashMap<>()).put(component.getClass(), component);
    }

    @Override
    public <T extends Component> T getComponent(int entityId, Class<T> componentType) {
        return (T) components.getOrDefault(entityId, new HashMap<>()).get(componentType);
    }

    @Override
    public boolean hasComponent(int entityId, Class<? extends Component> componentType) {
        return components.getOrDefault(entityId, new HashMap<>()).containsKey(componentType);
    }

    @Override
    public void removeComponent(int entityId, Class<? extends Component> componentType) {
        components.getOrDefault(entityId, new HashMap<>()).remove(componentType);
    }

    @Override
    public void dispose() {

    }
}
