package io.github.uniclog.game.component;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import io.github.uniclog.game.engine.Component;


public class AnimationComponent implements Component {

    private String atlasKey = "";
    public Float stateTime = 0f;
    private Animation.PlayMode playMode = Animation.PlayMode.LOOP;

    private Animation<TextureRegionDrawable> animation;
    private String nextAnimation = "";

    // player/idle_00
    // player/idle_01
    // player/idle_02
    public void nextAnimation(String atlasKey, AnimationType type) {
        this.atlasKey = atlasKey;
        this.nextAnimation = String.format("%s/%s", atlasKey, type.atlasKey);
    }
}
