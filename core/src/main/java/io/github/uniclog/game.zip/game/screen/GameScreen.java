package io.github.uniclog.game.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Logger;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import io.github.uniclog.game.Core;
import io.github.uniclog.game.engine.SystemManager;
import io.github.uniclog.game.engine.WorldEngine;
import io.github.uniclog.game.system.MovementSystem;
import io.github.uniclog.game.system.RenderSystem;

public class GameScreen implements Screen {
    private static Logger log = new Logger(GameScreen.class.getName());

    private Core core;
    private Stage stage = new Stage(new ExtendViewport(16f, 9f));
    private WorldEngine worldEngine;
    private SystemManager systemManager;
    private OrthographicCamera camera;
    private int frames;
    private float elapsedTime;
    private static final int TARGET_UPS = 60;
    private static final float TIME_PER_UPDATE = 1f / TARGET_UPS;
    private float deltaAccumulated = 0;
    private int updates;
    private BitmapFont font;

    private SpriteBatch batch;
    private Texture texture;

    public GameScreen(Core core) {
        this.core = core;
        this.worldEngine = new WorldEngine();
        this.systemManager = new SystemManager();
        this.camera = new OrthographicCamera();
    }

    @Override
    public void show() {
        batch = new SpriteBatch();
        font = new BitmapFont();

        systemManager.addSystem(new MovementSystem());
        //systemManager.addSystem(new RenderSystem(new SpriteBatch()));
    }

    @Override
    public void render(float delta) {
        deltaAccumulated += delta;

        // Очистка экрана
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


        // Увеличьте счетчик кадров и вычислите FPS
        frames++;
        elapsedTime += delta;
        if (elapsedTime >= 1.0f) {
            elapsedTime = 0;
            frames = 0;
        }

        // Отрисовка
        systemManager.update(0); // Вызов с нулевым временем для рендеринга
        renderPerformanceInfo();
    }

    private void renderPerformanceInfo() {
        batch.begin();
        font.draw(batch, "UPS: " + updates, 10, Gdx.graphics.getHeight() - 10);
        font.draw(batch, "FPS: " + Gdx.graphics.getFramesPerSecond(), 10, Gdx.graphics.getHeight() - 30);
        batch.end();
    }


    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
