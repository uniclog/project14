package io.github.uniclog.learn.ecs.system;

import com.badlogic.gdx.graphics.OrthographicCamera;
import io.github.uniclog.learn.ecs.component.ComponentManager;
import io.github.uniclog.learn.ecs.component.PositionComponent;

public class CameraSystem {
    private OrthographicCamera camera;
    private ComponentManager componentManager;

    public CameraSystem(ComponentManager componentManager, OrthographicCamera camera) {
        this.camera = camera;
        this.componentManager = componentManager;
    }

    public void update(int entity, float deltaTime) {
        // Получите позицию объекта, за которым должна следовать камера
        PositionComponent playerPosition = componentManager.getComponent(entity, PositionComponent.class);
        if (playerPosition != null) {
            camera.position.set(playerPosition.x, playerPosition.y, 0);
            camera.update();
        }
    }
}
