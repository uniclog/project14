package io.github.uniclog.game.system;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import io.github.uniclog.game.engine.ComponentManager;
import io.github.uniclog.game.engine.InjectedObject;
import io.github.uniclog.game.engine.System;

public class RenderSystem implements System {
    @InjectedObject
    private Stage stage;
    @InjectedObject
    private ComponentManager componentManager;

    @Override
    public void update(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.getViewport().apply();
        stage.act(delta);
        stage.draw();
    }
}
