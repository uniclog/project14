package io.github.uniclog.game.component;

public enum AnimationType {
    IDLE, RUN, ATTACK, DEATH, OPEN;
    public String atlasKey = this.toString().toLowerCase();
}
