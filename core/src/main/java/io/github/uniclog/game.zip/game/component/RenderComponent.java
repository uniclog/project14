package io.github.uniclog.game.component;

import com.badlogic.gdx.graphics.Texture;
import io.github.uniclog.game.engine.Component;

public class RenderComponent implements Component  {
    public Texture texture;

    public RenderComponent(Texture texture) {
        this.texture = texture;
    };
}
