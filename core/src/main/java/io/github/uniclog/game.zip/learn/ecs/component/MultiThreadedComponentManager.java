package io.github.uniclog.learn.ecs.component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MultiThreadedComponentManager implements ComponentManager {
    private ExecutorService executorService;
    private Map<Integer, Map<Class<? extends Component>, Component>> components;

    public MultiThreadedComponentManager() {
        executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        components = new HashMap<>();
    }

    @Override
    public void addComponent(int entityId, Component component) {
        executorService.execute(() -> {
            components.computeIfAbsent(entityId, k -> new HashMap<>()).put(component.getClass(), component);
        });
    }

    @Override
    public <T extends Component> T getComponent(int entityId, Class<T> componentType) {
        return (T) components.getOrDefault(entityId, new HashMap<>()).get(componentType);
    }

    @Override
    public boolean hasComponent(int entityId, Class<? extends Component> componentType) {
        return components.getOrDefault(entityId, new HashMap<>()).containsKey(componentType);
    }

    @Override
    public void removeComponent(int entityId, Class<? extends Component> componentType) {
        executorService.execute(() -> {
            components.getOrDefault(entityId, new HashMap<>()).remove(componentType);
        });
    }

    @Override
    public void dispose() {
        executorService.shutdown();
        try {
            executorService.awaitTermination(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // Обработка прерывания
        }
    }
}
