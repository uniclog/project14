package io.github.uniclog.learn.ecs.component;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class TextureComponent implements Component {
    public TextureRegion region = null;
}
