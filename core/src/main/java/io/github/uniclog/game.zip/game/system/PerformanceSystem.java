package io.github.uniclog.game.system;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.uniclog.game.component.PerformanceComponent;
import io.github.uniclog.game.engine.System;

public class PerformanceSystem implements System {
    private SpriteBatch batch;
    private BitmapFont font;
    private float timeSinceLastUpdate;
    private int frames;
    private int updates;
    private PerformanceComponent performanceComponent;

    public PerformanceSystem(SpriteBatch batch) {
        this.batch = batch;
        this.font = new BitmapFont();
        this.timeSinceLastUpdate = 0;
        this.frames = 0;
        this.updates = 0;
        this.performanceComponent = new PerformanceComponent(); // Создаем один раз
    }

    @Override
    public void update(float delta) {
        timeSinceLastUpdate += delta;
        frames++;
        if (timeSinceLastUpdate >= 1.0f) {
            performanceComponent.fps = frames;
            performanceComponent.ups = updates;
            timeSinceLastUpdate = 0;
            frames = 0;
            updates++;
        }
        render();
    }

    public void render() {
        batch.begin();
        font.draw(batch, "FPS: " + performanceComponent.fps, 10, Gdx.graphics.getHeight() - 10);
        font.draw(batch, "UPS: " + performanceComponent.ups, 10, Gdx.graphics.getHeight() - 30);
        batch.end();
    }
}
