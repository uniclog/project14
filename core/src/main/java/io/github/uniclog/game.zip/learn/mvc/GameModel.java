package io.github.uniclog.learn.mvc;

public class GameModel {
    private int score;

    public void update(float deltaTime) {
        score++;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
