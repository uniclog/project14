package io.github.uniclog.game.component;

import io.github.uniclog.game.engine.Component;

public class PerformanceComponent implements Component {
    public float fps;
    public float ups;

    public PerformanceComponent() {
        this.fps = 0;
        this.ups = 0;
    }
}
