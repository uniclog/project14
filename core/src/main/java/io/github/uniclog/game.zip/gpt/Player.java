package io.github.uniclog.gpt;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.*;

public class Player extends Sprite {
    private Body body; // Физическое тело персонажа

    // Новый конструктор с параметрами
    public Player(Texture texture, World world, float startX, float startY) {
        super(texture);

        // Создаем тело в заданной позиции
        createBody(world, startX, startY);
    }

    private void createBody(World world, float x, float y) {
        // Определение тела
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(x, y); // Установка начальной позиции

        body = world.createBody(bodyDef);

        // Создание формы тела (например, прямоугольник)
        PolygonShape shape = new PolygonShape();
        //shape.setAsBox(0.5f, 0.5f);
        shape.setAsBox(getWidth() / 2 / 100f, getHeight() / 2 / 100f); // Задайте размеры в метрах

        // Создание фиксации
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f; // Плотность
        fixtureDef.friction = 0.5f; // Трение
        fixtureDef.restitution = 0.5f; // Отскок
        body.createFixture(fixtureDef);

        // Освобождение ресурсов
        shape.dispose();
    }

    public void update(float delta) {
        // Обновление позиции спрайта в соответствии с физическим телом
        setPosition(body.getPosition().x - getWidth() / 2, body.getPosition().y - getHeight() / 2);
        setRotation(body.getAngle() * (180 / (float)Math.PI)); // Угловое положение
    }

    public Body getBody() {
        return body; // Возвращаем физическое тело
    }
}
