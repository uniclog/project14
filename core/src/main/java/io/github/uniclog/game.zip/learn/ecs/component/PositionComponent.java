package io.github.uniclog.learn.ecs.component;

public class PositionComponent implements Component {
    public float x, y;
    public PositionComponent(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
