package io.github.uniclog.gpt;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

public class GameScreen extends ScreenAdapter {
    private SpriteBatch batch;
    private Player player;
    private World world;
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private OrthographicCamera camera;
    private float ds = 100.0f;

    public GameScreen() {
        // Инициализация физики и других систем
        Box2D.init();

        // Создание мира
        world = new World(new Vector2(0, -(9.8f * 512)), false); // Гравитация вниз
        batch = new SpriteBatch(); // Создание SpriteBatch

        // Загрузка карты
        map = new TmxMapLoader().load("tilemap-2.tmx"); // Укажите путь к вашей карте Tiled
        renderer = new OrthogonalTiledMapRenderer(map);

        // Получение размеров карты
        int mapWidth = map.getProperties().get("width", Integer.class) * map.getProperties().get("tilewidth", Integer.class);
        int mapHeight = map.getProperties().get("height", Integer.class) * map.getProperties().get("tileheight", Integer.class);


        // Инициализация камеры
        camera = new OrthographicCamera();
        //float width = 15360, height = 10240;
        //float width = Gdx.graphics.getWidth(), height = Gdx.graphics.getHeight();
        float width = Gdx.graphics.getWidth()*4, height = Gdx.graphics.getHeight()*4;
        camera.setToOrtho(false, width, height);
        //camera.position.set(0, 0, 0); // Устанавливаем положение камеры в нижний левый угол
        camera.update();


        // Установка позиции игрока в центр карты
        float centerX = mapWidth / 2; // Преобразуем в метры, если 100 пикселей равны 1 метру mapWidth / 2 / 100f
        float centerY = mapHeight / 2; // Преобразуем в метры
        player = new Player(new Texture("player.png"), world, centerX, centerY);


        createPhysicsForTiles();
    }

    @Override
    public void render(float delta) {
        // Очистка экрана
        Gdx.gl.glClearColor(0.70f, 0.70f, 0.9f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Обработка ввода
        handleInput(delta);

        // Обновление позиции игрока
        player.update(delta);

        // Установка позиции камеры к телу игрока
        camera.position.set(player.getBody().getPosition().x, player.getBody().getPosition().y, 0);
        camera.update();

        camera.update();
        // Установка камеры для рендеринга
        renderer.setView(camera);
        renderer.render(); // Отрисовка карты

        // Рендеринг элементов
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        player.draw(batch);  // Рисуем игрока
        batch.end();

        // Обновление физического мира
        world.step(delta, 6, 2);
    }

    private void createPhysicsForTiles() {
        TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get("platform"); // Замените на имя вашего слоя
        for (int row = 0; row < layer.getHeight(); row++) {
            for (int col = 0; col < layer.getWidth(); col++) {
                TiledMapTileLayer.Cell cell = layer.getCell(col, row);
                if (cell != null && cell.getTile() != null) {
                    if (/* проверка свойства отдельно */ true) { // Замените условием для нужного свойства
                        createBodyForTile(col, row);
                    }
                }
            }
        }
    }
    private void createBodyForTile(int col, int row) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody;

        // Позиция в мире (умножьте на размер тайла, чтобы учесть пиксели в метрах)
        bodyDef.position.set(col * 512f + 5.12f / 2f, row * 512f + 5.12f / 2f); // Установка по центру тайла

        Body body = world.createBody(bodyDef);
        PolygonShape shape = new PolygonShape();

        // Задаем размеры физического тела как половину размера тайла
        shape.setAsBox(5.12f / 2, 5.12f / 2); // 5.12 метра

        // Создание фиксации
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f; // Плотность
        fixtureDef.friction = 0.5f; // Трение
        fixtureDef.restitution = 0.0f; // Упругость (0.0 для неподвижных объектов)
        body.createFixture(fixtureDef);

        shape.dispose(); // Освобождаем ресурсы после использования
    }

    private void handleInput(float delta) {
        // Управление игроком
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            player.getBody().setLinearVelocity(-(100f*ds), player.getBody().getLinearVelocity().y); // Движение влево
        } else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            player.getBody().setLinearVelocity(100f*ds, player.getBody().getLinearVelocity().y); // Движение вправо
        } else {
            //player.getBody().setLinearVelocity(0, player.getBody().getLinearVelocity().y); // Остановка по горизонтали
        }

        if (Gdx.input.isKeyPressed(Input.Keys.UP)){// && player.getBody().getLinearVelocity().y == 0) {
            player.getBody().applyForceToCenter(new Vector2(0, 100f*ds), true);//applyLinearImpulse(new Vector2(0, 100f*ds), player.getBody().getWorldCenter(), true); // Прыжок
        } else if (Gdx.input.isKeyPressed(Input.Keys.DOWN)){// && player.getBody().getLinearVelocity().y == 0) {
            player.getBody().applyLinearImpulse(new Vector2(0, -(100f*ds)), player.getBody().getWorldCenter(), true); // Прыжок
        }
    }

    @Override
    public void dispose() {
        batch.dispose(); // Освобождение ресурсов
        player.getTexture().dispose(); // Освобождение текстуры персонажа
        renderer.dispose(); // Освобождение ресурсов карты
        map.dispose(); // Освобождение ресурсов карты
        world.dispose(); // Освобождение мира
    }
}
