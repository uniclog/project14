package io.github.uniclog.game.engine;

import io.github.uniclog.game.engine.internal.SafeDisposable;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@Slf4j
public class WorldEngine implements SafeDisposable {
    // сущности
    private final List<Entity> entities = new ArrayList<>();

    private final Map<String, ComponentListener<?>> componentListeners = new HashMap<>();
    // системы
    private final List<System> systems = new ArrayList<>();

    // обьекты которые инжектятся
    private final Map<Class<?>, Object> dependencies = new HashMap<>();


    public Entity createEntity() {
        return new Entity(entities.size());
    }

    public void inject(Class<?> dependencyType, Object dependency) {
        Stream.concat(systems.stream(), componentListeners.values().stream())
            .forEach(object -> {
                Class<?> clazz = object.getClass();
                for (Field field : clazz.getDeclaredFields()) {
                    if (field.isAnnotationPresent(InjectedObject.class) && field.getType().equals(dependencyType)) {
                        field.setAccessible(true);
                        try {
                            field.set(object, dependency);
                        } catch (IllegalAccessException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            });
        dependencies.put(dependencyType, dependency);
    }

    public void injectDependenciesIn(Object object) {
        dependencies.forEach((cl, dep) -> {
            for (Field field : object.getClass().getDeclaredFields()) {
                if (field.isAnnotationPresent(InjectedObject.class) && field.getType().equals(cl)) {
                    field.setAccessible(true);
                    try {
                        field.set(object, dep);
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }


    public void addSystem(Class<? extends System> systemObject) {
        try {
            // добавлем систему
            System system = systemObject.getDeclaredConstructor().newInstance();
            systems.add(system);
            // добавляем имеющиеся зависимости
            injectDependenciesIn(system);
        } catch (Exception e) {
            log.error("Error adding system: {}", e.getMessage());
        }
    }

    public void addSystem(System system) {
        // добавлем систему
        systems.add(system);
        // добавляем имеющиеся зависимости
        injectDependenciesIn(system);
    }

    public <T extends Component> void addComponentListener(Class<? extends ComponentListener<T>> componentListenerDeclaration) {
        try {
            // добавляем обработчик для компоента
            ComponentListener<T> componentListener = componentListenerDeclaration.getDeclaredConstructor().newInstance();
            componentListeners.put(componentListener.getComponentName(), componentListener);
            // добавляем имеющиеся зависимости
            injectDependenciesIn(componentListener);
        } catch (Exception e) {
            log.error("Error adding component listener: {}", e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public void addEntity(Entity entity) {
        try {
            entity.getComponents().forEach((key, value) -> {
                ComponentListener<?> compLis = componentListeners.get(key);
                ComponentListener<Component> listener = (ComponentListener<Component>) compLis;
                listener.onCompAdded(entity, value);
            });
            entities.add(entity);
        } catch (Exception e) {
            log.error("Error adding entity: {}, message: {}", entity, e.getMessage(), e);
        }
    }

    public void removeEntity(Entity entity) {
        entities.remove(entity);
    }

    public void update(float delta) {
        for (System system : systems) {
            system.update(delta);
        }
    }

    public List<Entity> getEntitiesWithComponents(Class<? extends Component>... componentClasses) {
        List<Entity> result = new ArrayList<>();
        for (Entity entity : entities) {
            boolean hasAllComponents = true;
            for (Class<? extends Component> componentClass : componentClasses) {
                if (!entity.hasComponent(componentClass)) {
                    hasAllComponents = false;
                    break;
                }
            }
            if (hasAllComponents) {
                result.add(entity);
            }
        }
        return result;
    }

    @Override
    public Logger getLogger() {
        return log;
    }

    @Override
    public void dispose() {
        // todo реализовать очистку
    }
}
