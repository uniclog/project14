package io.github.uniclog.learn.mvc;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GameView {
    private SpriteBatch batch;
    private BitmapFont font;
    private GameModel model;

    public GameView(GameModel model) {
        this.model = model;
        batch = new SpriteBatch();
        font = new BitmapFont();
    }

    public void render() {
        batch.begin();
        font.draw(batch, "Score: " + model.getScore(), 10, 10);
        batch.end();
    }

    public void dispose() {
        batch.dispose();
        font.dispose();
    }
}
