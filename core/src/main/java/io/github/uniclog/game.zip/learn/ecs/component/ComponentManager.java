package io.github.uniclog.learn.ecs.component;

public interface ComponentManager {
    //private Map<Integer, Map<Class<? extends Component>, Component>> components;
    //public ComponentManager() {
    //    components = new HashMap<>();
    //}
    void addComponent(int entityId, Component component);

    <T extends Component> T getComponent(int entityId, Class<T> componentType);

    boolean hasComponent(int entityId, Class<? extends Component> componentType);

    void removeComponent(int entityId, Class<? extends Component> componentType);

    void dispose();
}
