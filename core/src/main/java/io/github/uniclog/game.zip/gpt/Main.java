package io.github.uniclog.gpt;

import com.badlogic.gdx.*;

/**
 * {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms.
 */
public class Main extends Game {
    @Override
    public void create() {
        setScreen(new GameScreen()); // Устанавливаем экран игры
    }
}
