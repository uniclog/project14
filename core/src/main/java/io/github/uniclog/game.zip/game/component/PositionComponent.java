package io.github.uniclog.game.component;

import io.github.uniclog.game.engine.Component;

public class PositionComponent implements Component {
    public float x, y;
    public PositionComponent(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
