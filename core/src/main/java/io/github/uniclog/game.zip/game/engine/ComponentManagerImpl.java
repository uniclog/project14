package io.github.uniclog.game.engine;

public class ComponentManagerImpl implements ComponentManager {
    @Override
    public void addComponent(int entityId, Component component) {

    }

    @Override
    public <T extends Component> T getComponent(int entityId, Class<T> componentType) {
        return null;
    }

    @Override
    public boolean hasComponent(int entityId, Class<? extends Component> componentType) {
        return false;
    }

    @Override
    public void removeComponent(int entityId, Class<? extends Component> componentType) {

    }

    @Override
    public void dispose() {

    }
}
