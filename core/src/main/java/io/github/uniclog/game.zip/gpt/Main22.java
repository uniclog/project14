package io.github.uniclog.gpt;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector3;

/**
 * {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms.
 */
public class Main22 extends ApplicationAdapter implements InputProcessor {

    TiledMap tiledMap;
    OrthographicCamera camera;
    TiledMapRenderer tiledMapRenderer;

    private float delta = 0.1f;
    private float moveSpeed = 4f;
    private Vector3 targetPosition;

    private boolean movingUp, movingDown, movingLeft, movingRight;

    @Override
    public void create() {
        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 1000, 1000);
        targetPosition = new Vector3(camera.position);
        camera.update();
        tiledMap = new TmxMapLoader().load("tileset.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Плавное перемещение камеры
        if (movingUp) {
            targetPosition.y += moveSpeed * delta;
        }
        if (movingDown) {
            targetPosition.y -= moveSpeed * delta;
        }
        if (movingLeft) {
            targetPosition.x -= moveSpeed * delta;
        }
        if (movingRight) {
            targetPosition.x += moveSpeed * delta;
        }

        // Плавное перемещение камеры к целевой позиции
        camera.position.lerp(targetPosition, 0.9f);
        camera.update();


        tiledMapRenderer.setView(camera);
        tiledMapRenderer.render();
    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        switch (keycode) {
            case Keys.UP:
                movingUp = true;
                break;
            case Keys.DOWN:
                movingDown = true;
                break;
            case Keys.LEFT:
                movingLeft = true;
                break;
            case Keys.RIGHT:
                movingRight = true;
                break;
        }
        return true; // Сигнализирует, что событие было обработано
    }

    @Override
    public boolean keyUp(int keycode) {
        switch (keycode) {
            case Keys.UP:
                movingUp = false;
                break;
            case Keys.DOWN:
                movingDown = false;
                break;
            case Keys.LEFT:
                movingLeft = false;
                break;
            case Keys.RIGHT:
                movingRight = false;
                break;
        }
        return true; // Сигнализирует, что событие было обработано
    }

    @Override
    public boolean keyTyped(char c) {
        return false;
    }

    @Override
    public boolean touchDown(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchUp(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchCancelled(int i, int i1, int i2, int i3) {
        return false;
    }

    @Override
    public boolean touchDragged(int i, int i1, int i2) {
        return false;
    }

    @Override
    public boolean mouseMoved(int i, int i1) {
        return false;
    }

    @Override
    public boolean scrolled(float v, float v1) {
        return false;
    }
}
