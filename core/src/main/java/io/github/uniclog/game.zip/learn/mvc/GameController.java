package io.github.uniclog.learn.mvc;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;

public class GameController extends ApplicationAdapter {
    private GameModel model;
    private GameView view;

    @Override
    public void create() {
        model = new GameModel();
        view = new GameView(model);
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1); // Clear screen
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        model.update(Gdx.graphics.getDeltaTime());
        view.render();
    }

    @Override
    public void dispose() {
        view.dispose();
    }
}
