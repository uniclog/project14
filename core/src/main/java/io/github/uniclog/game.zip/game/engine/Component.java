package io.github.uniclog.game.engine;

public interface Component {
}
