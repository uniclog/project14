package io.github.uniclog.learn.ecs.system;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.uniclog.learn.ecs.component.ComponentManager;
import io.github.uniclog.learn.ecs.component.PositionComponent;
import io.github.uniclog.learn.ecs.component.SpriteComponent;

public class RenderSystem {
    private ComponentManager componentManager;
    private SpriteBatch batch;
    private OrthographicCamera camera;

    public RenderSystem(ComponentManager componentManager, SpriteBatch batch, OrthographicCamera camera) {
        this.componentManager = componentManager;
        this.batch = batch;
        this.camera = camera;
    }
    public void render(int entityId) {
        camera.update();

        PositionComponent position = componentManager.getComponent(entityId, PositionComponent.class);
        SpriteComponent sprite = componentManager.getComponent(entityId, SpriteComponent.class);
        if (position != null && sprite != null) {
            batch.begin();
            batch.setProjectionMatrix(camera.combined);
            sprite.sprite.setPosition(position.x, position.y);
            sprite.sprite.draw(batch);
            batch.end();
        }
    }
}
