package io.github.uniclog.game.component;

import io.github.uniclog.game.engine.Component;

public class VelocityComponent implements Component {
    public float vx, vy;
    public VelocityComponent(float x, float y) {
        this.vx = vx;
        this.vy = vy;
    }
}
