package io.github.uniclog.learn.ecs;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import io.github.uniclog.learn.ecs.component.*;
import io.github.uniclog.learn.ecs.system.CameraSystem;
import io.github.uniclog.learn.ecs.system.MovementSystem;
import io.github.uniclog.learn.ecs.system.RenderSystem;

public class GameAdapter extends ApplicationAdapter {
    private SpriteBatch batch;
    private int[] entities;
    private Texture texture;
    private TiledMap tiledMap;
    private OrthographicCamera camera;
    private OrthogonalTiledMapRenderer tiledMapRenderer;

    private ComponentManager componentManager;
    private MovementSystem movementSystem;
    private RenderSystem renderSystem;
    private CameraSystem cameraSystem;

    @Override
    public void create() {
        batch = new SpriteBatch();
        entities = new int[10];
        componentManager = new ComponentManagerImpl();
        texture = new Texture("player.png");

        // Загрузка TMX-файла
        tiledMap = new TmxMapLoader().load("tileset.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        // Настройка камеры
        camera = new OrthographicCamera();
        float width = Gdx.graphics.getWidth()/3, height = Gdx.graphics.getHeight()/3;
        camera.setToOrtho(false, width, height);
        camera.update();

        // Создаем системы ECS
        movementSystem = new MovementSystem(componentManager);
        cameraSystem = new CameraSystem(componentManager, camera);
        renderSystem = new RenderSystem(componentManager, batch, camera);
        // Создаем первую сущность (Entity)
        int entityId = createEntity();
        // Добавляем компоненты к сущности
        componentManager.addComponent(entityId, new PositionComponent(100, 100));
        componentManager.addComponent(entityId, new VelocityComponent(0, 0));
        componentManager.addComponent(entityId, new SpriteComponent(new Sprite(texture)));

    }

    // Создание сущности
    private int createEntity() {
        for (int i = 0; i < entities.length; i++) {
            if (entities[i] == 0) {
                entities[i] = i + 1;
                return entities[i];
            }
        }
        // Если массив заполнен, увеличьте его размер
        int[] newEntities = new int[entities.length * 2];
        System.arraycopy(entities, 0, newEntities, 0, entities.length);
        entities = newEntities;
        return createEntity();
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        // Обновление камеры
        //camera.update();
        cameraSystem.update(entities[0], Gdx.graphics.getDeltaTime()); // Передаем deltaTime
        // Рендеринг карты
        tiledMapRenderer.setView(camera);
        tiledMapRenderer.render();
        // Обработка ввода
        handleInput();
        // Обновление систем ECS
        for (int entityId : entities) {
            if (entityId != 0) { // Проверка на 0
                movementSystem.update(entityId, Gdx.graphics.getDeltaTime());
                renderSystem.render(entityId);
            }
        }
    }

    // Обработка ввода
    private void handleInput() {
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            componentManager.getComponent(entities[0], VelocityComponent.class).x = -1000; // Влево
        } else if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            componentManager.getComponent(entities[0], VelocityComponent.class).x = 1000; // Вправо
        } else {
            componentManager.getComponent(entities[0], VelocityComponent.class).x = 0; // Стоять
        }
        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            componentManager.getComponent(entities[0], VelocityComponent.class).y = 1000; // Вверх
        } else if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            componentManager.getComponent(entities[0], VelocityComponent.class).y = -1000; // Вниз
        } else {
            componentManager.getComponent(entities[0], VelocityComponent.class).y = 0; // Стоять
        }
    }

    @Override
    public void dispose() {
        batch.dispose();
        texture.dispose();
    }
}
