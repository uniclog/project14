package io.github.uniclog.game.engine;

public interface ComponentManager {
    void addComponent(int entityId, Component component);

    <T extends Component> T getComponent(int entityId, Class<T> componentType);

    boolean hasComponent(int entityId, Class<? extends Component> componentType);

    void removeComponent(int entityId, Class<? extends Component> componentType);

    void dispose();
}
