package io.github.uniclog.learn.ecs.component;

public interface Component {
}
