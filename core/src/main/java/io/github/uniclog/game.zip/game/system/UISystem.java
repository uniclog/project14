package io.github.uniclog.game.system;

import com.badlogic.gdx.scenes.scene2d.Stage;
import io.github.uniclog.game.engine.System;

public class UISystem implements System {
    private Stage stage;

    public UISystem(Stage stage) {
        this.stage = stage;
    }

    @Override
    public void update(float delta) {
        stage.act(delta);
        stage.draw();
    }

}
