package io.github.uniclog.game.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import io.github.uniclog.game.Core;
import io.github.uniclog.game.component.AnimationComponent;
import io.github.uniclog.game.component.ImageComponent;
import io.github.uniclog.game.engine.Entity;
import io.github.uniclog.game.engine.WorldEngine;
import io.github.uniclog.game.engine.internal.SceneUtils;
import io.github.uniclog.game.system.RenderSystem;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;

@Slf4j
public class GameScreen2 implements Screen, SceneUtils {

    private final TextureAtlas textureAtlas;
    private final Stage stage;


    private final WorldEngine worldEngine;


    public GameScreen2(Core core) throws IllegalAccessException {
        textureAtlas = new TextureAtlas(Gdx.files.internal("example/atlas/gameObjects.atlas"));
        stage = new Stage(new ExtendViewport(16f, 9f));

        worldEngine = new WorldEngine();
        worldEngine.addSystem(RenderSystem.class);
        worldEngine.addComponentListener(ImageComponent.ImageComponentListener.class);
        worldEngine.inject(Stage.class, stage);

        // добавление сущности 1
        var entity = worldEngine.createEntity();
        entity.addComponent(ImageComponent.class);
        // new TextureRegion(textureAtlas.findRegion("player"), 0, 1 * 48, 48, 48)
        var image = new Image();
        image.setSize(4f, 4f);
        entity.inject(Image.class, image);

        entity.addComponent(AnimationComponent.class);

        worldEngine.addEntity(entity);

        // добавление сущности 2
        var entity2 = worldEngine.createEntity();
        entity2.addComponent(ImageComponent.class);
        // new TextureRegion(textureAtlas.findRegion("slime"), 0, 0, 32, 32)
        var image2 = new Image();
        image2.setSize(4f, 4f);
        image2.setPosition(12f, 0f);
        entity2.inject(Image.class, image2);
        worldEngine.addEntity(entity2);
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        worldEngine.update(delta);
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        safeDispose(stage);
        safeDispose(textureAtlas);

        worldEngine.disposeSafely();
    }

    @Override
    public Logger getLogger() {
        return log;
    }
}
