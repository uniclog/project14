package io.github.uniclog.learn.ecs.system;

import io.github.uniclog.learn.ecs.component.ComponentManager;
import io.github.uniclog.learn.ecs.component.PositionComponent;
import io.github.uniclog.learn.ecs.component.VelocityComponent;

public class MovementSystem {
    private ComponentManager componentManager;

    public MovementSystem(ComponentManager componentManager) {
        this.componentManager = componentManager;
    }

    public void update(int entityId, float deltaTime) {
        PositionComponent position = componentManager.getComponent(entityId, PositionComponent.class);
        VelocityComponent velocity = componentManager.getComponent(entityId, VelocityComponent.class);

        if (position != null && velocity != null) {
            position.x += velocity.x * deltaTime;
            position.y += velocity.y * deltaTime;
        }
    }
}
